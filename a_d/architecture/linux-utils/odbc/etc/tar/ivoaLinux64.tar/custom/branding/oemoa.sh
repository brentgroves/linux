#!/usr/bin/ksh
# Copyright (c) 1995-2016. Progress Software Corporation. All Rights Reserved..
#
# oemoa.sh : shell script to brand the OpenAccess SDK 8.1 Client for ODBC on UNIX/Linux
# ===================================================================================== 
#
# To execute this script:  
#               oemoa.sh
#
# prerequisites:
#  1) install the OpenAccess SDK - Client for ODBC on UNIX/Linux
#  2) modify the environment variables in SetEnvVars according to
#     your branding environment
#
# basic description:
#  this script copies the OpenAccess SDK - Client for ODBC to
#  the OEMTARGETDIR.  It executes the OpenAccess SDK - Branding Tool 
#  for OpenAccess SDK.  The OAINSTDIR and branding result (OEMTARGETDIR)
#  is copied to the TESTDIR.  The branded OpenAccess SDK - Client for ODBC
#  configuration is modified and example is started up.  Uncomment DoTest
#  to skip this automatic test.
#
# SetEnvVars()
# set the environment variables
# adapt the following environment variables before running this script
#
SetEnvVars()
{
# -------------------------------------------------------------------------
# OAINSTDIR directory where you installed 
# the unbranded OpenAccess Client 
#--------------------------------------------------------------------------
OAINSTDIR=/usr/oaodbc810

# -------------------------------------------------------------------------
# BRANDDIR directory with the branding tool  
# -------------------------------------------------------------------------
BRANDDIR=$OAINSTDIR/custom/branding

# -------------------------------------------------------------------------
# OEMTARGETDIR target directory where the branded driver
# will be stored (= branding directory)
# -------------------------------------------------------------------------
OEMTARGETDIR=$BRANDDIR/oaodbcbranding

# -------------------------------------------------------------------------
# TESTDIR test directory where the branded driver will be installed for test
# -------------------------------------------------------------------------
TESTDIR=$HOME/oa810/oaodbcbranded$BUILD

# -------------------------------------------------------------------------
# OEM Prefix assigned to your company
#

# WARNING: Do not make up a prefix. Register for it through
# the Progress Partner Web site. Registering a prefix 
# through the Web site guarantees that each OEM 
# customer has a unique 2-character signature. A unique
# signature prevents library conflicts with other embedded 
# drivers that may be on a user�s system when your application 
# is running.
# -------------------------------------------------------------------------
OEMPREFIX=OA

# -------------------------------------------------------------------------
# OEM password to unlock the driver
# -------------------------------------------------------------------------
OEMPASSWORD=secret                 

# -------------------------------------------------------------------------
# Your short Company Name
# -------------------------------------------------------------------------
SCOMPANYNAME=

# -------------------------------------------------------------------------
# Your Product Name
# -------------------------------------------------------------------------
PRODUCTNAME=

# -------------------------------------------------------------------------
# Your long Company Name
# -------------------------------------------------------------------------
COMPANYNAME=

# overwrite the pre-set environment variables
OEMTARGETDIR=$BRANDDIR/oaodbcbranding
TESTDIR=$HOME/oa81/oaodbcbranded$BUILD
OEMPREFIX=OA
OEMPASSWORD=secret
SCOMPANYNAME="MyCompany"
PRODUCTNAME="MyProduct"
COMPANYNAME="My Company Name"

BRANDEXE=brandodbc$BUILD

# release depending
OAVER=27
DriverDescr="DataDirect OpenAccess SDK 8.1"

}


# SetOSDepVars()
# overwrite SLEXT and LIBVAR
#
SetOSDepVars()
{
# os dep variables
SLEXT=so                # Shared library extention
LIBVAR=LD_LIBRARY_PATH  # Shared library search path

if [ `uname` = "AIX" ] ; then
   SLEXT=so           # Shared library extention
   LIBVAR=LIBPATH     # Shared library search path
elif [ `uname` = "HP-UX" ] ; then
   if [ `uname -m` = "ia64" ] ; then
      SLEXT=so           # Shared library extention
      LIBVAR=SHLIB_PATH  # Shared library search path
   else
   SLEXT=sl           # Shared library extention
   LIBVAR=SHLIB_PATH  # Shared library search path
   fi
else
   SLEXT=so                # Shared library extention
   LIBVAR=LD_LIBRARY_PATH  # Shared library search path
fi  
}

# ShowParameters()
#
#
ShowParameters()
{
echo "Source Directory OAINSTDIR: $OAINSTDIR"
echo "Target Directory OEMTARGETDIR: $OEMTARGETDIR"
echo "Test   Directory TESTDIR: $TESTDIR"
echo ""
echo "OEMPREFIX       $OEMPREFIX"
echo "OEMPASSWORD     $OEMPASSWORD"
echo "SCOMPANYNAME    $SCOMPANYNAME"
echo "PRODUCTNAME     $PRODUCTNAME"
echo "COMPANYNAME     $COMPANYNAME"
echo ""
}

#
# Brand the files
#
Brand()
{
"$BRANDDIR/$BRANDEXE" "$OEMTARGETDIR" clientserver -N "$OEMPREFIX" -P $OEMPASSWORD -s "$SCOMPANYNAME" -p "$PRODUCTNAME" -X n
status=$?
if [  $status -ne 0 ] ; then
  echo "ERROR : branding $OEMTARGETDIR failed with status = $status"
  exit 1
fi
}


#
# Prepare the branding directory
#
PrepareBrandDir()
{
echo "copying files to $OEMTARGETDIR"
echo "copying driver file..."
cp -f $OAINSTDIR/lib$BUILD/ivoa${OAVER}.${SLEXT} $OEMTARGETDIR
chmod u+w $OEMTARGETDIR/ivoa${OAVER}.${SLEXT}

echo "copying product license file..."
if [ "$BUILD" = "64" ] ; then
  cp -f $OAINSTDIR/OAODBC${BUILD}.LIC  $OEMTARGETDIR
  chmod u+w $OEMTARGETDIR/OAODBC${BUILD}.LIC  
else
  cp -f $OAINSTDIR/OAODBC32.LIC  $OEMTARGETDIR
  chmod u+w $OEMTARGETDIR/OAODBC32.LIC  
fi

echo "copying files to $OEMTARGETDIR: DONE"
}


#
# Install the test driver
#
InstallTestDriver()
{
echo "copying files to $TESTDIR"

echo "copying driver files"
cp -R $OAINSTDIR/* $TESTDIR
# */

echo "copying branded driver file ivoa${OAVER}.${SLEXT} ..."
cp -f $OEMTARGETDIR/ivoa${OAVER}.${SLEXT} $TESTDIR/lib$BUILD
chmod a=rx $TESTDIR/lib$BUILD/ivoa${OAVER}.${SLEXT}

echo "copying product license file OA${OEMPREFIX}.LIC ..."
cp -f $OEMTARGETDIR/OA${OEMPREFIX}.LIC $TESTDIR

if [ "$BUILD" = "64" ] ; then                           
  rm -f $TESTDIR/OAODBC${BUILD}.LIC     
else                                                    
  rm -f $TESTDIR/OAODBC32.LIC  
fi                                                      
echo "copying files to $TESTDIR: DONE"
}


#
# Generate the ODBCINI file
#
GenODBCINI()
{
echo "modifying the odbc.ini file..."
rm -f $TESTDIR/odbc$BUILD.ini
sed -e "s/`echo $OAINSTDIR | sed -e 's/\\//\\\\\\//g'`/`echo $TESTDIR | sed -e 's/\\//\\\\\\//g'`/" <$OAINSTDIR/odbc$BUILD.ini >$TESTDIR/odbc$BUILD.ini
chmod 666 $TESTDIR/odbc$BUILD.ini
}

#
# Generate the oa[64].sh file 
#
GenShEnvFile()
{
echo "modifying the environment scripts..."
rm -f $TESTDIR/oaodbc$BUILD.sh
rm -f $TESTDIR/.oaodbc$BUILD.sh
sed -e "s/`echo $OAINSTDIR | sed -e 's/\\//\\\\\\//g'`/`echo $TESTDIR | sed -e 's/\\//\\\\\\//g'`/" <$OAINSTDIR/.oaodbc$BUILD.sh >$TESTDIR/.oaodbc$BUILD.sh
chmod 755 $TESTDIR/.oaodbc$BUILD.sh
ln -f $TESTDIR/.oaodbc$BUILD.sh  $TESTDIR/oaodbc$BUILD.sh
}

#
# customizing odbcisql
#
CustomOdbcisql()
{
ODBCISQL_INI=$TESTDIR/tools/odbcisql.ini
echo "customizing odbcisql..."
rm -f $ODBCISQL_INI

echo "[Common]"  > $ODBCISQL_INI
echo "About=$SCOMPANYNAME $PRODUCTNAME Interactive SQL (ODBC) Version 7.0\\\n(c) Copyright 1995-2011 $COMPANYNAME. All rights reserved." >> $ODBCISQL_INI

chmod a=r $ODBCISQL_INI
}

#
# Execute the driver test example[64] file
#
DoTest()
{
. $TESTDIR/.oaodbc$BUILD.sh
echo "this test will start up example"
$TESTDIR/samples/example/example$BUILD
}

#
# Check Environment variables 
#
CheckEnvVariables()
{
# check OEM variables are set
if [ -z "$OEMTARGETDIR" ] ; then
   echo "ERROR : OEMTARGETDIR not set"
   exit 1
fi
if [ -z "$OEMPREFIX" ] ; then
   echo "ERROR : OEMPREFIX not set"
   exit 1
fi
if [ -z "$OEMPASSWORD" ] ; then
   echo "ERROR : OEMPASSWORD not set"
   exit 1
fi

# check dir and files
if [ ! -d $OAINSTDIR ] ; then
   echo "ERROR: directory OAINSTDIR $OAINSTDIR does not exist"
   exit 1
fi 

if [ ! -d $BRANDDIR ] ; then 
   echo "ERROR: directory BRANDDIR $BRANDDIR does not exist"
   exit 1
fi  
if [ ! -x $BRANDDIR/$BRANDEXE ] ; then 
   echo "ERROR : branding tool $BRANDDIR/$BRANDEXE does not exist"
   exit 1
fi  

if [ -d $OEMTARGETDIR ] ; then
   echo "WARNING : target directory $OEMTARGETDIR already exist, do you want to remove it [Y/N]"
   read ANSWER
   if [ $ANSWER = "Y" ] ; then
      rm -rf $OEMTARGETDIR
   else
      exit 1
   fi
fi

if [ -d $TESTDIR ] ; then
   echo "WARNING : test directory $TESTDIR already exist, do you want to remove it [Y/N]"
   read ANSWER
   if [ $ANSWER = "Y" ] ; then
      rm -rf $TESTDIR
   else
      exit 1
   fi
fi
}


#
# Start of the oemoa.sh script
# =============================
#
# BUILD empty or 64 
BUILD=
if [ "$BUILD" = "64" ] ; then
 P1=64
else
 P1=32
fi
echo "You're about to execute the branding script for UNIX/Linux on a ${P1}-bit platform, press ENTER to continue"
read ANSWER

SetOSDepVars
SetEnvVars
CheckEnvVariables

ShowParameters
echo "Press a key to continue or CTRL-C to abort"
read ANSWER

mkdir -p $OEMTARGETDIR
if [  $? -ne 0 ] ; then
  echo "ERROR : mkdir OEMTARGETDIR $OEMTARGETDIR failed"
  exit 1
fi

if [ ! -r $OAINSTDIR/oaodbc$BUILD.sh ] ; then 
   echo "ERROR : OpenAccess startup script $OAINSTDIR/oaodbc$BUILD.sh does not exist"
   exit 1
fi

. $OAINSTDIR/oaodbc$BUILD.sh

PrepareBrandDir
Brand

echo "Do you want to install the branded driver in your test directory [Y/N]?"
read ANSWER
if [ $ANSWER = "Y" ] ; then
   mkdir -p $TESTDIR
   if [  $? -ne 0 ] ; then
      echo "ERROR : mkdir TESTDIR $TESTDIR failed"
      exit 1
   fi
   InstallTestDriver
   GenODBCINI
   GenShEnvFile
   CustomOdbcisql
else
echo "Branding tool test is finished.  Goodbye!"
exit
fi

echo "Do you want to test the branded driver [Y/N]?"
read ANSWER
if [ $ANSWER = "Y" ] ; then
   DoTest
else
echo "Branding tool test is finished.  Goodbye!"
fi
