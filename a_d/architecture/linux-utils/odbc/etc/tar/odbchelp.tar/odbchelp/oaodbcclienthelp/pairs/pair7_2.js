var pairs =
{
"sql":{"escape":1}
,"escape":{"sequences":1}
,"sequences":{"sql":1,"information":1,"supported":1}
,"information":{"sql":1}
,"supported":{"odbc":1}
,"odbc":{"client":1}
}
;Search.control.loadWordPairs(pairs);
