var pairs =
{
"data":{"types":1,"source":1}
,"types":{"data":1,"supported":1}
,"supported":{"odbc":1,"detailed":1,"data":1}
,"odbc":{"client":1}
,"client":{"depend":1}
,"depend":{"data":1}
,"source":{"connecting":1}
,"connecting":{"data":1}
,"detailed":{"information":1}
,"information":{"supported":1}
}
;Search.control.loadWordPairs(pairs);
