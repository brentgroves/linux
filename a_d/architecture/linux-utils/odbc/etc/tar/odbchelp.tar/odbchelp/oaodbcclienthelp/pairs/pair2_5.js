var pairs =
{
"unicode":{"non-unicode":1,"application":1,"driver":1}
,"non-unicode":{"odbc":1}
,"odbc":{"drivers":1}
,"drivers":{"driver":1}
,"driver":{"handles":1}
,"handles":{"function":1}
,"function":{"calls":1}
,"calls":{"unicode":1}
,"application":{"determines":1}
,"determines":{"whether":1}
,"whether":{"called":1}
,"called":{"unicode":1}
}
;Search.control.loadWordPairs(pairs);
