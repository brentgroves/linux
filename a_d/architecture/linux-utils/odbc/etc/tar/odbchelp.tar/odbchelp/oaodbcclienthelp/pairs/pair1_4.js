var pairs =
{
"data":{"types":1}
,"types":{"supported":1}
,"supported":{"help":1,"openaccess":1}
,"help":{"topic":1}
,"topic":{"lists":1}
,"lists":{"data":1}
,"openaccess":{"sdk":1}
,"sdk":{"sql":1}
,"sql":{"engine":1}
,"engine":{"third-party":1}
,"third-party":{"sql":1}
}
;Search.control.loadWordPairs(pairs);
