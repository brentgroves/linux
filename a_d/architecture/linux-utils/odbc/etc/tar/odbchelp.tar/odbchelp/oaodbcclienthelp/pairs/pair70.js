var pairs =
{
"ldap":{"server":1,"port":1}
,"server":{"port":1}
,"port":{"attribute":1,"(prt)":1,"service":1,"default":1}
,"attribute":{"port":1}
,"(prt)":{"description":1}
,"description":{"specifies":1}
,"specifies":{"ldap":1}
,"service":{"port":1}
,"default":{"389":1}
,"389":{"gui":1}
,"gui":{"tab":1}
,"tab":{"general":1}
,"general":{"tab":1}
}
;Search.control.loadWordPairs(pairs);
