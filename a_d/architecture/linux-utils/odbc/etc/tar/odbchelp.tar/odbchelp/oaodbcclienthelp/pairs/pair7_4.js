var pairs =
{
"developing":{"odbc":1,"applications":1}
,"odbc":{"applications":1}
,"applications":{"linux\u002Funix":1}
,"linux\u002Funix":{"important":1,"using":1}
,"important":{"remember":1}
,"remember":{"differences":1}
,"differences":{"developing":1}
,"using":{"double-byte":1,"utf-16":1}
,"double-byte":{"character":1}
,"character":{"sets":1}
,"sets":{"linux\u002Funix":1}
,"utf-16":{"applications":1}
}
;Search.control.loadWordPairs(pairs);
