var pairs =
{
"managing":{"connections":1}
,"connections":{"updates":1}
,"updates":{"guidelines":1,"improve":1}
,"guidelines":{"section":1}
,"section":{"help":1}
,"help":{"manage":1}
,"manage":{"connections":1}
,"improve":{"system":1}
,"system":{"performance":1}
,"performance":{"odbc":1}
,"odbc":{"applications":1}
}
;Search.control.loadWordPairs(pairs);
