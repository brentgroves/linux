var pairs =
{
"threading":{"odbc":1}
,"odbc":{"specification":1,"drivers":1}
,"specification":{"requires":1}
,"requires":{"odbc":1}
,"drivers":{"thread-safe":1}
,"thread-safe":{"fail":1}
,"fail":{"database":1}
,"database":{"requests":1}
,"requests":{"made":1}
,"made":{"separate":1}
,"separate":{"threads":1}
}
;Search.control.loadWordPairs(pairs);
