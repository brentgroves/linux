var pairs =
{
"configuring":{"data":1}
,"data":{"sources":1}
,"sources":{"odbc":1,"configured":1}
,"odbc":{"client":1,"administrator":1}
,"client":{"windows":1,"data":1,"client\u002Fserver":1}
,"windows":{"configure":1,"platforms":1}
,"configure":{"32-bit":1}
,"32-bit":{"64-bit":1}
,"64-bit":{"client":1,"data":1}
,"client\u002Fserver":{"environment":1}
,"environment":{"windows":1}
,"platforms":{"odbc":1}
,"administrator":{"32-bit":1}
,"configured":{"manner":1}
}
;Search.control.loadWordPairs(pairs);
