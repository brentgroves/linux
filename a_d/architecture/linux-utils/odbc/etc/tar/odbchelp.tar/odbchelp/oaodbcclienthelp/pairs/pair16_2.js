var pairs =
{
"using":{"stored":1,"third-party":1}
,"stored":{"procedures":1}
,"procedures":{"openaccess":1,"using":1}
,"openaccess":{"sdk":1}
,"sdk":{"sql":1}
,"sql":{"engine":1}
,"engine":{"supports":1,"refer":1,"documentation":1}
,"supports":{"stored":1}
,"third-party":{"sql":1}
,"refer":{"sql":1}
,"documentation":{"determine":1}
,"determine":{"level":1}
,"level":{"support":1}
,"support":{"stored":1}
}
;Search.control.loadWordPairs(pairs);
