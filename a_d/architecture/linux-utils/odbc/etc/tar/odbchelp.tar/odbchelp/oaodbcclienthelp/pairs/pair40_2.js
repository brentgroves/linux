var pairs =
{
"selecting":{"odbc":1}
,"odbc":{"functions":1}
,"functions":{"guidelines":1,"give":1}
,"guidelines":{"section":1}
,"section":{"help":1}
,"help":{"selecting":1}
,"give":{"best":1}
,"best":{"performance":1}
}
;Search.control.loadWordPairs(pairs);
