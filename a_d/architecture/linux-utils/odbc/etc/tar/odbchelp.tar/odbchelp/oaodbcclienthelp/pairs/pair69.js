var pairs =
{
"ldap":{"server":1}
,"server":{"host":1,"service":1}
,"host":{"attribute":1,"(hst)":1,"name":1}
,"attribute":{"host":1}
,"(hst)":{"description":1}
,"description":{"tcp\u002Fip":1}
,"tcp\u002Fip":{"host":1}
,"name":{"ldap":1}
,"service":{"host":1}
}
;Search.control.loadWordPairs(pairs);
